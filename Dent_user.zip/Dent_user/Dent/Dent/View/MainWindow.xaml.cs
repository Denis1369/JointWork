﻿using Dent.Model;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
using Dent.View;
using MaterialDesignThemes.Wpf;

namespace Dent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Service> allService = new List<Service>();
        public MainWindow()
        {
            InitializeComponent();
            LoadServicesTypes();
        }

        private void LoadServicesTypes()
        {
            using (var db = new DbDentistryContext())
            {
                allService = db.Services.ToList();
                ApplySearchFilters();
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            LoadServicesTypes();
        }

        private void ServicesBtn_Click(object sender, RoutedEventArgs e)
        {
            ListService.Items.Clear();
            if(allService != null)
                allService.Clear();
            if (sender is Button button)
            {
                string btn_content = button.Content.ToString();

                using (var db = new DbDentistryContext())
                {
                    var service_types = db.ServicesTypes.ToList();

                    var service_type_current = service_types.FirstOrDefault(st =>
                        st.ServicesTypeTitle.Equals(btn_content, StringComparison.OrdinalIgnoreCase));

                    if (service_type_current != null)
                    {
                        int service_type_id = service_type_current.ServicesTypeId;

                        var services = db.Services
                            .Where(s => s.ServicesTypeId == service_type_id)
                            .ToList();

                        foreach ( var service in services )
                        {
                            ListService.Items.Add(new View.UserControl1(service));
                            allService.Add(service);
                        }
                    }
                }
            }
            ApplySearchFilters() ;
        }
        private void UpdateList(List<Service> services)
        {
            if (ListService != null)
                ListService.Items.Clear();
            foreach (var service in services)
            {
                ListService.Items.Add(new UserControl1(service));
            }
        }
        private void ApplySearchFilters()
        {
            if (allService == null) return;

            var filteredGoods = allService.AsEnumerable();
            var search = search_tb.Text;
            if (!string.IsNullOrWhiteSpace(search))
            {
                filteredGoods = filteredGoods.Where(g =>
                    g.ServicesTitle != null && g.ServicesTitle.Contains(search, StringComparison.OrdinalIgnoreCase));
            }
            var sort = (sort_cb.SelectedItem as ComboBoxItem).Content.ToString();
            switch (sort)
            {
                case "По названию (А-Я)":
                    filteredGoods = filteredGoods.OrderBy(g => g.ServicesTitle);
                    break;
                case "По названию (Я-А)":
                    filteredGoods = filteredGoods.OrderByDescending(g => g.ServicesTitle);
                    break;
                case "По цене (возрастание)":
                    filteredGoods = filteredGoods.OrderBy(g => g.ServicesPrice);
                    break;
                case "По цене (убывание)":
                    filteredGoods = filteredGoods.OrderByDescending(g => g.ServicesType);
                    break;
            }
            UpdateList(filteredGoods.ToList());
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplySearchFilters();
        }

        private void sort_cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplySearchFilters();
        }

        private void reviewBtn_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AddReviews());

        }
    }
}