﻿using System;
using System.Collections.Generic;

namespace dentistry.Model;

public partial class Entry
{
    public int EntryId { get; set; }

    public DateTime? DateTime { get; set; }

    public string? UserName { get; set; }

    public string? UserEmail { get; set; }

    public string? EntryStatus { get; set; }

    public static async Task<bool> UpdateEntryStatusAsync(int entryId, string newStatus)
    {
        using (var context = new DbDentistryContext())
        {
            var entry = await context.Entries.FindAsync(entryId);
            if (entry == null)
                return false;

            entry.EntryStatus = newStatus;
            await context.SaveChangesAsync();
            return true;
        }
    }
}
