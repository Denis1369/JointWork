﻿using dentistry.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dentistry.PageF
{
    /// <summary>
    /// Логика взаимодействия для EditingPage.xaml
    /// </summary>
    public partial class EditingPage : Page
    {
        public EditingPage()
        {
            InitializeComponent();
            Load();
        }
        private void Load() 
        {
            using (var context = new DbDentistryContext()) 
            {
                var i = context.Entries.ToList();
                EntriesDataGrid.ItemsSource = context.Entries.ToList();
            }
        }

        private async void ComboBox_DropDownClosed(object sender, EventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.DataContext is Entry entry)
            {
                string newStatus = comboBox.SelectedItem as string;

                bool isSuccess = await Entry.UpdateEntryStatusAsync(entry.EntryId, newStatus);

                if (isSuccess)
                {
                    Load(); // Обновляем данные
                }
                else
                {
                    MessageBox.Show("Ошибка!");
                }
            }
        }
    }
}
