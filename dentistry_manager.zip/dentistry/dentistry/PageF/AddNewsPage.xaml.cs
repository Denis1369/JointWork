﻿using dentistry.Model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dentistry.PageF
{
    /// <summary>
    /// Логика взаимодействия для AddNewsPage.xaml
    /// </summary>
    public partial class AddNewsPage : Page
    {
        private byte[] _img;

        public AddNewsPage()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string status = News.AddNews(TitleT.Text, DescT.Text, _img);
            MessageBox.Show(status);
            if ("Успешно сохранено" == status)
            {
                _img = [];
                TitleT.Text = "";
                DescT.Text = "";
            }
        }

        private void SelectImg_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Images|*.png;*.jpg;*.jpeg"
            };

            if (dialog.ShowDialog() == true)
            {
                _img = File.ReadAllBytes(dialog.FileName);
            }
        }
    }
}
