use db_dentistry;

ALTER TABLE manager 
MODIFY COLUMN manager_password VARCHAR(64) NOT NULL;

