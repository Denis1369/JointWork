﻿using System;
using System.Collections.Generic;

namespace JointWork;

public partial class Manager
{
    public int ManagerId { get; set; }

    public string ManagerPassword { get; set; } = null!;
}
