﻿using System;
using System.Collections.Generic;

namespace JointWork;

public partial class News
{
    public int NewsId { get; set; }

    public string? NewsTitle { get; set; }

    public string? NewsDesc { get; set; }

    public DateOnly? DatePublish { get; set; }

    public string? NewsImage { get; set; }

    public string DisplayedImage => (string)("../Resource/" + ((NewsImage == null || string.IsNullOrEmpty(NewsImage)) ? "picture.png" : NewsImage));
}
