﻿using JointWork.View;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JointWork
{
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            LoadNews();
        }

        private void LoadNews()
        {
            using (var db = new DbDentistryContext())
            {
                List<News> allNews = db.News.ToList();
                UpdateGoodsList(allNews);
            }
        }

        private void UpdateGoodsList(List<News> news)
        {
            ListNews.Items.Clear();
            foreach (var i in news)
            {
                ListNews.Items.Add(new NewsPattern(i));
            }
        }
    }
}